/* author Elliott Beeley */

function backgroundColor(){

    var color = document.getElementById('colorPicker').value;
    document.body.style.backgroundColor = color;

}

function fontColor(){

    const colorPicker = document.getElementById('colorPicker');
    const text = document.getElementById('text');
    text.style.color = colorPicker.value;

}